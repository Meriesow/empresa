<?php
include('conexao1.php');

if(isset($_POST['email']) || isset($_POST['senha'])) {

    if(strlen($_POST['email']) == 0) {
        function function_alert($messagee) {
            echo "<script>alert('$messagee');</script>";
        }
        function_alert("Preencha seu e-mail!" );
    } else if(strlen($_POST['senha']) == 0) {
        function function_alert($messagee) {
            echo "<script>alert('$messagee');</script>";
        }
        function_alert("Preencha sua senha!" );
    } else {

        $email = $mysqli->real_escape_string($_POST['email']);
        $senha = $mysqli->real_escape_string($_POST['senha']);

        $sql_code = "SELECT * FROM cadastros WHERE email = '$email' AND senha = '$senha'";
        // var_dump($sql_code);
        $sql_query = $mysqli->query($sql_code) or die("Falha na execução do código SQL: " . $mysqli->error);

        $quantidade = $sql_query->num_rows;

        if($quantidade == 1) {
            
            $usuario = $sql_query->fetch_assoc();

            if(!isset($_SESSION)) {
                session_start();
            }

            $_SESSION['id'] = $usuario['id'];
            $_SESSION['nome'] = $usuario['nome'];

            header("Location: ../usuarios/administrador/index.php");

        } else {
            function function_alert($messagee) {
                echo "<script>alert('$messagee');</script>";
            }
            function_alert("Senha ou e-mail inválidos" );
        }

    }

}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/login.css">
    <link rel="shortcut icon" href="../img/icon.png" type="image/x-icon">
     <!--Google link-->
     <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@200;300;400&family=Poppins:ital,wght@0,400;1,200;1,300&display=swap" rel="stylesheet">  
    <title>Login</title>
</head>
<body>
<section class="area-login">
        <div class="login">
             <div>
              <a href="../index.html"><img src="../img/logo.jpeg"></a>  
              </div>
               <h1 class="login-title">Acesse sua conta</h1>
             <form action="indox.php" method="POST">
                <input id="email" type="email" name="email" placeholder="E-mail">
                <input type="password" id="senha" name="senha" placeholder="Senha" maxlength="12">
                <input type="submit" value="Entrar">
            </form>
          <p>Não possui conta?<a href="cadastro.php">Criar conta</a></p>
       </div>
</section>
</body>
</html>