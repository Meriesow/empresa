<?php
include('conexao.php');

$showForm = true;
$message = "";

  



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST["nome"] ?? null;
    $email = $_POST["email"] ?? null;
    $telefone = $_POST["telefone"] ?? null;
    $senha = $_POST["senha"] ?? null;
    $confirmar_senha = $_POST["confirmar_senha"] ?? null;

    if (empty($nome) ||empty($email) || empty($telefone) || empty($senha) || empty($confirmar_senha)) {
        function function_alert($messagee) {
            echo "<script>alert('$messagee');</script>";
        }
        function_alert("Todos os campos são obrigatórios!");
    } elseif ($senha !== $confirmar_senha) {
        function function_alert($messagee) {
            echo "<script>alert('$messagee');</script>";
        }
        function_alert("Senhas não coincidem!");
    } else {
        $nome = $conn->real_escape_string($nome);
        $email = $conn->real_escape_string($email);
        $telefone = $conn->real_escape_string($telefone);
        $senha = $conn->real_escape_string($senha);
        $sql = "INSERT INTO cadastros (nome, email, telefone, senha) VALUES ('$nome', '$email','$telefone', '$senha')";

        if ($conn->query($sql) === TRUE) {
            $message = "<div class='alert alert-success'><img src='img/verificado.png' ><br>Cadastro realizado com sucesso! <a href='indox.php'>Faça o login!</a></div>";
            $showForm = false;
        } else {
            function function_alert($messagee) {
                echo "<script>alert('$messagee');</script>";
            }
            function_alert("Erro ao inserir dados!" ,$conn->error);
        }
    }
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/dre.css"> 
    <link rel="shortcut icon" href="../img/icon.png" type="image/x-icon">

     <!--Google link-->
	 <link rel="preconnect" href="https://fonts.googleapis.com">
	 <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	 <link href="https://fonts.googleapis.com/css2?family=Inter:wght@200;300;400&family=Poppins:ital,wght@0,400;1,200;1,300&display=swap" rel="stylesheet">  

   
    <title>Cadastro</title>
</head>
<body> 
   

    <?php
    if (!empty($message)) {
        echo $message;
    }

    if ($showForm):
    ?>
    <div class="box">
        <div class="img-box">
            <img src="../img/logoo.png">
        </div>
        <div class="form-box">
            <h2>Criar Conta</h2>
            <p> Já é um membro? <a href="indox.php"> Login </a> </p>
            <form action="cadastro.php" method="post">
            <div class="input-group">
                    <label for="nome">Nome</label>
                    <input type="text" name="nome" id="nome" placeholder="Digite o seu nome completo" required>
                </div>
                
                <div class="input-group">
                    <label for="email">E-mail:</label>
                    <input type="email" id="email" name="email" placeholder="Digite o seu e-mail" required>
                </div>
                <div class="input-group">
                   <label for="telefone">Celular</label>
                    <input type="text" name="telefone" id="telefone" minlength="15" placeholder="Digite o número de celular" required>
                </div>
                
                <div class="input-group w50">
                    <label for="senha">Senha:</label>
                    <input type="password" id="senha" name="senha" placeholder="Digite sua senha" required>
                </div>

                <div class="input-group w50">
                    <label for="confirmar_senha">Confirmar Senha:</label>
                    <input type="password" id="confirmar_senha" name="confirmar_senha" placeholder="Confirme a senha" required>
                </div>
                
                <div class="submit-group">
                    <input type="submit" value="Cadastrar">
                </div>
    
            </form>
            </div>
<script>
                 
              var telefone = document.getElementById("telefone");
              telefone.addEventListener("input", () => {
              var limparValor = telefone.value.replace(/\D/g, "").substring(0,11);
               var numerosArray = limparValor.split("");
             var numeroFormatado = "";
                  if(numerosArray.length > 0){
                  numeroFormatado += `(${numerosArray.slice(0,2).join("")})`;
                    }
                    if(numerosArray.length > 2){
                        numeroFormatado += ` ${numerosArray.slice(2,7).join("")}`;
                    }
                    if(numerosArray.length > 7){
                        numeroFormatado += `-${numerosArray.slice(7,11).join("")}`;
                     } telefone.value = numeroFormatado;
                });
</script>

        </div>
    <?php endif; ?>

</body>
</html>
