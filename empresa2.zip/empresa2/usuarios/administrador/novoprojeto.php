<?php

include('../../acesso/protect.php');

@include '../config.php';


if(isset($_POST['add_product'])){
   $p_name = $_POST['p_name'];
   $p_price = $_POST['p_price'];
   $p_image = $_FILES['p_image']['name'];
   $p_image_tmp_name = $_FILES['p_image']['tmp_name'];
   $p_image_folder = 'uploaded_img/'.$p_image;

   $insert_query = mysqli_query($conn, "INSERT INTO `products`(name, price, image) VALUES('$p_name', '$p_price', '$p_image')") or die('query failed');

   if($insert_query){
      move_uploaded_file($p_image_tmp_name, $p_image_folder);
      $message[] = 'product add succesfully';
   }else{
      $message[] = 'could not add the product';
   }
};

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   $delete_query = mysqli_query($conn, "DELETE FROM `products` WHERE id = $delete_id ") or die('query failed');
   if($delete_query){
      header('location:admin.php');
      $message[] = 'product has been deleted';
   }else{
      header('location:admin.php');
      $message[] = 'product could not be deleted';
   };
};

if(isset($_POST['update_product'])){
   $update_p_id = $_POST['update_p_id'];
   $update_p_name = $_POST['update_p_name'];
   $update_p_price = $_POST['update_p_price'];
   $update_p_image = $_FILES['update_p_image']['name'];
   $update_p_image_tmp_name = $_FILES['update_p_image']['tmp_name'];
   $update_p_image_folder = 'uploaded_img/'.$update_p_image;

   $update_query = mysqli_query($conn, "UPDATE `products` SET name = '$update_p_name', price = '$update_p_price', image = '$update_p_image' WHERE id = '$update_p_id'");

   if($update_query){
      move_uploaded_file($update_p_image_tmp_name, $update_p_image_folder);
      $message[] = 'product updated succesfully';
      header('location:admin.php');
   }else{
      $message[] = 'product could not be updated';
      header('location:admin.php');
   }

}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="shortcut icon" href="img/icon.png" type="image/x-icon">
	 <!--Google link-->
	 <link rel="preconnect" href="https://fonts.googleapis.com">
	 <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	 <link href="https://fonts.googleapis.com/css2?family=Inter:wght@200;300;400&family=Poppins:ital,wght@0,400;1,200;1,300&display=swap" rel="stylesheet">  

	<title>Administrador</title>
</head>
<body>


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="voluntários.php" class="brand">
			<i class='bx bxs-map-pin'></i>
			<span class="text">Administrador</span>
		</a>
		<ul class="side-menu top">
			<li>
				<a href="index.php">
				<i class='bx bxs-home' ></i>
					<span class="text">Inicio</span>
				</a>
			</li>
			<li>
				<a href="voluntários.php">
					<i class='bx bxs-user-detail' ></i>
					<span class="text">Voluntários</span>
				</a>
			</li>
			<li  class="active">
				<a href="projetos.php">
				<i class='bx bxs-layer-plus'></i>
					<span class="text">Projetos</span>
				</a>
			</li>
			<li>
				<a href="equipe.php">
				<i class='bx bxs-group' ></i>
					<span class="text">Equipe</span>
				</a>
			</li>
			<li>
				<a href="certificados.php">
				<i class='bx bxs-certification' ></i>
					<span class="text">Certificados</span>
				</a>
			</li>
			<li>
				<a href="usuário.php">
				<i class='bx bxs-user' ></i>
					<span class="text">Eu</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
				<a href="configurações.php">
					<i class='bx bxs-cog' ></i>
					<span class="text">Configuração</span>
				</a>
			</li>
			<li>
				<a href="../../index.html" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="text">Sair</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<a href="voluntários.php" class="nav-link"></a>
			<a href="#" class="notification">
				<i class='bx bxs-bell' ></i>
				<span class="num"></span><!--PEDIR HELP PARA O PROFESSOR-->
			</a>
			<a href="usuario.php" class="profile">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Projetos</h1>
					<ul class="breadcrumb">
						<li>
							<a href="projetos.php">Projetos</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="index.php">Início</a>
						</li>
					</ul>
				</div>
				<a href="novoprojeto.php" class="btn-download">
					<i class='bx bx-plus'></i>
					<span class="text">Novo Projeto</span>
				</a>
			</div>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->

    <?php

if(isset($message)){
   foreach($message as $message){
      echo '<div class="message"><span>'.$message.'</span> <i class="fas fa-times" onclick="this.parentElement.style.display = `none`;"></i> </div>';
   };
};

?>

<?php @include '../header.php'; ?>

<div class="container">

<section class="products">

   <h1 class="heading">latest products</h1>

   <div class="box-container">

<?php      
     $select_products = mysqli_query($conn, "SELECT * FROM `products`");
	 if(mysqli_num_rows($select_products) > 0){
		while($row = mysqli_fetch_assoc($select_products)){
      ?>

      <form action="" method="post">
         <div class="box">
            <img src="uploaded_img/<?php echo $fetch_product['image']; ?>" alt="">
            <h3><?php echo $fetch_product['name']; ?></h3>
            <div class="price"><?php echo $fetch_product['price']; ?></div>
            <input type="hidden" name="product_name" value="<?php echo $fetch_product['name']; ?>">
            <input type="hidden" name="product_price" value="<?php echo $fetch_product['price']; ?>">
            <input type="hidden" name="product_image" value="<?php echo $fetch_product['image']; ?>">
            <input type="submit" class="btn" value="add to cart" name="add_to_cart">
         </div>
      </form>

      <?php
         };
      };
      ?>

   </div>

</section>

</div>
    </div>
<!-- custom js file link  -->
<script src="js/script.js"></script>
	
</body>
</html>
