<?php

include('../../acesso/protect.php');

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="shortcut icon" href="img/icon.png" type="image/x-icon">
	 <!--Google link-->
	 <link rel="preconnect" href="https://fonts.googleapis.com">
	 <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	 <link href="https://fonts.googleapis.com/css2?family=Inter:wght@200;300;400&family=Poppins:ital,wght@0,400;1,200;1,300&display=swap" rel="stylesheet">  

	<title>Administrador</title>
</head>
<body>


	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="voluntários.php" class="brand">
			<i class='bx bxs-map-pin'></i>
			<span class="text">Administrador</span>
		</a>
		<ul class="side-menu top">
			<li>
				<a href="index.php">
				<i class='bx bxs-home' ></i>
					<span class="text">Inicio</span>
				</a>
			</li>
			<li>
				<a href="voluntários.php">
					<i class='bx bxs-user-detail' ></i>
					<span class="text">Voluntários</span>
				</a>
			</li>
			<li>
				<a href="projetos.php">
				<i class='bx bxs-report' ></i>
					<span class="text">Projetos</span>
				</a>
			</li>
			<li>
				<a href="equipe.php">
				<i class='bx bxs-group' ></i>
					<span class="text">Equipe</span>
				</a>
			</li>
			<li>
				<a href="certificados.php">
				<i class='bx bxs-certification' ></i>
					<span class="text">Certificados</span>
				</a>
			</li>
			<li class="active">
				<a href="usuário.php">
					<i class='bx bxs-user' ></i>
					<span class="text">Eu</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
				<a href="configurações.php">
					<i class='bx bxs-cog' ></i>
					<span class="text">Configuração</span>
				</a>
			</li>
			<li>
				<a href="../../index.html" class="logout">
					<i class='bx bxs-log-out-circle' ></i>
					<span class="text">Sair</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu' ></i>
			<a href="voluntários.php" class="nav-link"></a>
			<a href="#" class="notification">
				<i class='bx bxs-bell' ></i>
				<span class="num"></span><!--PEDIR HELP PARA O PROFESSOR-->
			</a>
			<a href="usuario.php" class="profile">
			</a>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<div class="head-title">
				<div class="left">
					<h1>Usuário</h1>
					<ul class="breadcrumb">
						<li>
							<a href="usuário.php">Eu</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="index.php">Inicio</a>
						</li>
					</ul>
				</div>
				<a href="#" class="btn-download">
					<i class='bx bxs-edit'></i>
					<span class="text">Editar</span>
				</a>
			</div>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="js/script.js"></script>
</body>
</html>